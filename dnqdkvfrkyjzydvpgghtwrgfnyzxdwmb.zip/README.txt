Triangle Pixel ¡ª arXiv Submission
=================================

To compile:
  pdflatex paper.tex
  pdflatex paper.tex   (twice for references)

Or upload to Overleaf:
  1. Create new project
  2. Upload all files in this directory
  3. Set compiler to pdfLaTeX
  4. Click Recompile

Files:
  paper.tex     ¡ª Main manuscript (8 pages, 2-column)
  fig1_grid.pdf ¡ª Triangular grid geometry
  fig2_channels.pdf ¡ª Channel assignment pattern  
  fig3_sensor_bars.pdf ¡ª PSNR comparison chart
  fig4_anisotropy.pdf ¡ª Directional isotropy radar
  fig5_ai_speed.pdf ¡ª AI vs ISP + speed benchmark
  fig6_arch.pdf ¡ª System architecture diagram
